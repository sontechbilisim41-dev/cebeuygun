# Cebeuygun E-commerce Platform

A comprehensive multi-vendor e-commerce platform with express delivery capabilities (10-30 minutes), built with modern microservices architecture.

## 🚀 Features

- **Multi-vendor marketplace** with seller onboarding and management
- **Express delivery** system with real-time courier tracking
- **Mobile-first** React Native apps for customers and couriers
- **Web dashboards** for sellers and administrators
- **Real-time notifications** and order tracking
- **Advanced search** with Elasticsearch integration
- **Payment processing** with multiple payment methods
- **Microservices architecture** with event-driven communication

## 🏗 Architecture

The platform consists of:

### Frontend Applications
- **Customer Mobile App** (React Native) - Order placement and tracking
- **Courier Mobile App** (React Native) - Delivery management
- **Seller Web Panel** (React) - Inventory and order management
- **Admin Web Panel** (React) - Platform administration

### Backend Services
- **Auth Service** (Go) - User authentication and authorization
- **Catalog Service** (Go) - Product and category management
- **Search Service** (Go + Elasticsearch) - Product search and filtering
- **Order Service** (Go) - Order processing and management
- **Payment Service** (Go) - Payment processing and transactions
- **Courier Service** (Go) - Delivery and route optimization
- **Promotion Service** (Go) - Discounts and loyalty programs
- **Notification Service** (Go) - Multi-channel notifications
- **Reporting Service** (Go) - Analytics and business intelligence
- **Pricing Service** (Go) - Dynamic pricing and calculations
- **BFF Service** (Node.js) - Backend for Frontend API gateway

### Infrastructure
- **PostgreSQL** - Primary database (per service)
- **Redis** - Caching and session management
- **Apache Kafka** - Event streaming and messaging
- **Elasticsearch** - Search and analytics
- **MinIO** - Object storage for files and images
- **Nginx** - API gateway and load balancer

## 🛠 Quick Start

### Prerequisites

- Node.js 20+
- Go 1.22+
- Docker & Docker Compose
- pnpm 8+

### Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd cebeuygun-platform
   ```

2. **Install dependencies**
   ```bash
   pnpm install
   ```

3. **Setup environment**
   ```bash
   cp .env.example .env
   # Edit .env with your configuration
   ```

4. **Start infrastructure services**
   ```bash
   pnpm run docker:dev
   ```

5. **Wait for services to be healthy**
   ```bash
   # Check service health
   docker compose -f docker-compose.dev.yml ps
   ```

6. **Start the platform**
   ```bash
   # Start all services in development mode
   pnpm run dev
   ```

### Verify Installation

- **API Gateway**: http://localhost (Nginx)
- **BFF Service**: http://localhost:3001
- **Auth Service**: http://localhost:8001
- **Seller Dashboard**: http://localhost:3002
- **Admin Dashboard**: http://localhost:3003

## 🧪 Testing

```bash
# Run all tests
pnpm run test

# Run linting
pnpm run lint

# Type checking
pnpm run type-check
```

## 📱 Mobile Development

### Customer App
```bash
cd apps/customer-rn
npx expo start
```

### Courier App
```bash
cd apps/courier-rn
npx expo start
```

## 🚀 Production Deployment

### Docker Images
```bash
# Build all service images
docker build -t cebeuygun/auth services/auth/
docker build -t cebeuygun/catalog services/catalog/
# ... for each service
```

### Kubernetes Deployment
```bash
# Apply Kubernetes manifests
kubectl apply -f infra/k8s/
```

## 📊 Monitoring

- **Health Checks**: All services expose `/health` endpoints
- **Metrics**: Prometheus-compatible metrics
- **Logging**: Structured JSON logging
- **Tracing**: Distributed tracing support

## 🔒 Security

- **JWT Authentication** with refresh tokens
- **Role-based access control** (Customer, Seller, Courier, Admin)
- **Rate limiting** on API endpoints
- **Input validation** and sanitization
- **HTTPS/TLS** encryption
- **Database connection** encryption

## 📖 API Documentation

- **REST APIs**: OpenAPI 3.0 specifications in `/contracts/openapi/`
- **gRPC APIs**: Protocol Buffer definitions in `/contracts/proto/`
- **Generated Documentation**: Auto-generated from contracts

### Key Endpoints

#### Authentication
- `POST /api/auth/register` - User registration
- `POST /api/auth/login` - User login
- `POST /api/auth/refresh` - Token refresh

#### Catalog
- `GET /api/catalog/products` - List products
- `GET /api/catalog/products/search` - Search products
- `POST /api/catalog/products` - Create product (seller only)

#### Orders
- `POST /api/order/orders` - Create order
- `GET /api/order/orders/:id` - Get order details
- `PATCH /api/order/orders/:id/status` - Update order status

## 🔧 Development

### Code Structure
```
/
├── apps/              # Frontend applications
├── services/          # Backend microservices
├── contracts/         # API contracts (proto, OpenAPI)
├── packages/          # Shared packages
├── infra/            # Infrastructure configurations
└── docs/             # Documentation
```

### Adding a New Service

1. Create service directory in `/services/`
2. Add service configuration in `docker-compose.dev.yml`
3. Update API gateway routing in nginx configuration
4. Add service to CI/CD pipeline
5. Update documentation

### Environment Variables

Key environment variables (see `.env.example`):

- `DATABASE_URL` - PostgreSQL connection string
- `REDIS_URL` - Redis connection string
- `KAFKA_BROKERS` - Kafka broker list
- `JWT_SECRET` - JWT signing secret
- `ELASTICSEARCH_URL` - Elasticsearch endpoint

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

### Commit Convention

We use [Conventional Commits](https://www.conventionalcommits.org/):

- `feat:` - New features
- `fix:` - Bug fixes
- `docs:` - Documentation changes
- `style:` - Code style changes
- `refactor:` - Code refactoring
- `test:` - Test additions or modifications
- `chore:` - Build process or auxiliary tool changes

## 📝 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🆘 Support

- **Documentation**: [/docs](/docs)
- **Issues**: GitHub Issues
- **Discussions**: GitHub Discussions
- **Email**: support@cebeuygun.com

## 🏃‍♂️ Performance Targets

- **API Response Time**: < 200ms (95th percentile)
- **Search Response Time**: < 100ms
- **Order Processing**: < 5 seconds end-to-end
- **Express Delivery**: 10-30 minutes delivery time
- **Uptime**: 99.9% availability target

## 🌍 Multi-language Support

- Turkish (primary)
- English
- Extensible i18n framework

---

**Built with ❤️ for the express delivery revolution**